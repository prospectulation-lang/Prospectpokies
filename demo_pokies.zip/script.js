let credits = 100;
const symbols = ["🍒", "💎", "7️⃣", "🍋", "⭐", "🍀"];

const spinSound = document.getElementById("spinSound");
const winSound = document.getElementById("winSound");

document.getElementById("spinBtn").addEventListener("click", spin);

function spin() {
  if (credits <= 0) {
    alert("Out of credits! Refresh to restart.");
    return;
  }

  spinSound.play();
  credits -= 10;

  const reels = [];
  for (let i = 1; i <= 3; i++) {
    const symbol = symbols[Math.floor(Math.random() * symbols.length)];
    document.getElementById(`reel${i}`).textContent = symbol;
    reels.push(symbol);
  }

  // Win condition: 3 symbols match
  if (reels[0] === reels[1] && reels[1] === reels[2]) {
    credits += 50;
    winSound.play();
    setTimeout(() => alert("🎉 You win 50 credits!"), 200);
  }

  document.getElementById("credits").textContent = credits;
}
